#!/usr/bin/env python3
"""
Dust Collector System Analysis and Diagram Generator

Analyzes the event-driven dust collector codebase and generates
comprehensive architecture diagrams using Graphviz.

Usage:
    ./generate_diagrams.py [diagram_type]
    
    diagram_type can be: all, architecture, dataflow, statemachine, 
                        events, components, modules
"""

import os
import sys
import ast
import re
from pathlib import Path
from collections import defaultdict
import subprocess

# Color scheme for diagrams
COLORS = {
    'event_bus': '#667eea',
    'hardware': '#f56565',
    'tasks': '#48bb78',
    'util': '#ed8936',
    'tool': '#9f7aea',
    'gate': '#38b2ac',
    'fan': '#4299e1',
    'sensor': '#f6ad55',
    'background': '#ffffff',
    'text': '#2d3748',
    'border': '#cbd5e0'
}


class CodeAnalyzer:
    """Analyzes Python source code to extract architecture information"""
    
    def __init__(self, src_dir):
        self.src_dir = Path(src_dir)
        self.modules = {}
        self.imports = defaultdict(set)
        self.classes = defaultdict(list)
        self.events = defaultdict(set)  # module -> set of events
        self.event_publishers = defaultdict(set)  # event -> set of publishers
        self.event_subscribers = defaultdict(set)  # event -> set of subscribers
        
    def analyze(self):
        """Run complete analysis"""
        print("🔍 Analyzing codebase...")
        self._scan_modules()
        self._analyze_imports()
        self._analyze_events()
        print(f"   Found {len(self.modules)} modules")
        print(f"   Found {len(self.classes)} classes")
        print(f"   Found {len(self.event_publishers)} event types")
        
    def _scan_modules(self):
        """Find and parse all Python modules"""
        for py_file in self.src_dir.rglob('*.py'):
            if '__pycache__' in str(py_file):
                continue
            
            module_path = py_file.relative_to(self.src_dir)
            module_name = str(module_path).replace('/', '.').replace('.py', '')
            
            try:
                with open(py_file, 'r') as f:
                    tree = ast.parse(f.read(), filename=str(py_file))
                    self.modules[module_name] = {
                        'path': py_file,
                        'tree': tree,
                        'classes': [node.name for node in ast.walk(tree) 
                                   if isinstance(node, ast.ClassDef)]
                    }
            except Exception as e:
                print(f"   Warning: Could not parse {module_name}: {e}")
    
    def _analyze_imports(self):
        """Extract import relationships"""
        for module_name, module_info in self.modules.items():
            tree = module_info['tree']
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        self.imports[module_name].add(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        self.imports[module_name].add(node.module)
    
    def _analyze_events(self):
        """Extract event publish/subscribe patterns"""
        for module_name, module_info in self.modules.items():
            tree = module_info['tree']
            source = ast.unparse(tree)
            
            # Find publish calls
            publish_pattern = r'(?:event_bus|self\.event_bus|bus)\.publish\(["\'](\w+)["\']'
            for match in re.finditer(publish_pattern, source):
                event_name = match.group(1)
                self.event_publishers[event_name].add(module_name)
                self.events[module_name].add(event_name)
            
            # Find subscribe calls
            subscribe_pattern = r'(?:event_bus|self\.event_bus|bus)\.subscribe\(["\'](\w+)["\']'
            for match in re.finditer(subscribe_pattern, source):
                event_name = match.group(1)
                self.event_subscribers[event_name].add(module_name)
                self.events[module_name].add(event_name)


class DiagramGenerator:
    """Generates Graphviz diagrams from analyzed code"""
    
    def __init__(self, analyzer, output_dir):
        self.analyzer = analyzer
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def _run_dot(self, dot_content, output_file, dpi=150):
        """Execute Graphviz dot command"""
        dot_file = self.output_dir / f"{output_file.stem}.dot"
        
        # Write DOT file
        with open(dot_file, 'w') as f:
            f.write(dot_content)
        
        # Generate PNG
        cmd = ['dot', '-Tpng', f'-Gdpi={dpi}', '-o', str(output_file), str(dot_file)]
        try:
            subprocess.run(cmd, check=True, capture_output=True)
            print(f"   ✓ Generated {output_file.name}")
            # Clean up DOT file
            dot_file.unlink()
        except subprocess.CalledProcessError as e:
            print(f"   ✗ Error generating {output_file.name}: {e.stderr.decode()}")
        except FileNotFoundError:
            print("   ✗ Error: Graphviz not found. Install with: sudo apt-get install graphviz")
            sys.exit(1)
    
    def generate_architecture(self):
        """Generate system architecture diagram"""
        print("📐 Generating system architecture diagram...")
        
        dot = f'''digraph system_architecture {{
    rankdir=TB;
    bgcolor="{COLORS['background']}";
    node [shape=box, style="rounded,filled", fontname="Arial"];
    edge [fontname="Arial", fontsize=10];
    
    // Event Bus (central)
    subgraph cluster_event_bus {{
        label="Event Bus";
        style=filled;
        color="{COLORS['event_bus']}";
        fillcolor="{COLORS['event_bus']}20";
        
        event_bus [label="Event Bus\\n(Pub/Sub)", fillcolor="{COLORS['event_bus']}", fontcolor=white];
    }}
    
    // Hardware Layer
    subgraph cluster_hardware {{
        label="Hardware Abstraction Layer";
        style=filled;
        color="{COLORS['hardware']}";
        fillcolor="{COLORS['hardware']}20";
        
        tools [label="Tool Detection\\n(Current Sensors)", fillcolor="{COLORS['sensor']}"];
        gates [label="Blast Gates\\n(Servo Control)", fillcolor="{COLORS['gate']}"];
        fans [label="Fan Control\\n(Relay)", fillcolor="{COLORS['fan']}"];
        air_quality [label="Air Quality\\n(UART Sensor)", fillcolor="{COLORS['sensor']}"];
        io_expander [label="I/O Expander\\n(PCF8574)", fillcolor="{COLORS['hardware']}"];
    }}
    
    // Control Tasks
    subgraph cluster_tasks {{
        label="Control Tasks";
        style=filled;
        color="{COLORS['tasks']}";
        fillcolor="{COLORS['tasks']}20";
        
        tool_monitor [label="Tool Monitor", fillcolor="{COLORS['tasks']}"];
        gate_control [label="Gate Controller", fillcolor="{COLORS['tasks']}"];
        fan_control [label="Fan Controller", fillcolor="{COLORS['tasks']}"];
        air_monitor [label="Air Quality Monitor", fillcolor="{COLORS['tasks']}"];
    }}
    
    // Event flow
    tool_monitor -> event_bus [label="tool_on\\ntool_off"];
    event_bus -> gate_control [label="subscribe"];
    event_bus -> fan_control [label="subscribe"];
    gate_control -> event_bus [label="gate_opened\\ngate_closed"];
    fan_control -> event_bus [label="fan_on\\nfan_off"];
    air_monitor -> event_bus [label="air_quality"];
    
    // Hardware connections
    tool_monitor -> tools [style=dashed, label="read"];
    gate_control -> gates [style=dashed, label="control"];
    fan_control -> fans [style=dashed, label="control"];
    air_monitor -> air_quality [style=dashed, label="read"];
    
    // I2C bus
    {{tools, gates, io_expander}} -> i2c_bus [style=dotted, label="I²C"];
    i2c_bus [label="I²C Bus", shape=cylinder, fillcolor="{COLORS['border']}"];
}}'''
        
        self._run_dot(dot, self.output_dir / 'system_diagram_enhanced.png', dpi=150)
        self._run_dot(dot, self.output_dir / 'system_diagram_poster.png', dpi=300)
    
    def generate_dataflow(self):
        """Generate data flow diagram"""
        print("📊 Generating data flow diagram...")
        
        dot = f'''digraph dataflow {{
    rankdir=LR;
    bgcolor="{COLORS['background']}";
    node [shape=box, style="rounded,filled", fontname="Arial"];
    edge [fontname="Arial"];
    
    // Sensors
    current_sensor [label="Current Sensor\\n(ADS1115)", fillcolor="{COLORS['sensor']}"];
    air_sensor [label="Air Quality\\nSensor", fillcolor="{COLORS['sensor']}"];
    
    // Processing
    adc_read [label="ADC Reading\\n(I²C)", fillcolor="{COLORS['util']}"];
    threshold [label="Threshold\\nDetection", fillcolor="{COLORS['util']}"];
    debounce [label="Debouncing\\n(100ms)", fillcolor="{COLORS['util']}"];
    
    // Events
    events [label="Event\\nPublication", shape=ellipse, fillcolor="{COLORS['event_bus']}"];
    
    // Control
    gate_logic [label="Gate State\\nMachine", fillcolor="{COLORS['tasks']}"];
    fan_logic [label="Fan Control\\nLogic", fillcolor="{COLORS['tasks']}"];
    
    // Actuators
    servo [label="Servo\\nControl", fillcolor="{COLORS['gate']}"];
    relay [label="Relay\\nControl", fillcolor="{COLORS['fan']}"];
    
    // Flow
    current_sensor -> adc_read -> threshold -> debounce -> events;
    air_sensor -> events;
    events -> gate_logic -> servo;
    events -> fan_logic -> relay;
    
    // Labels
    adc_read -> threshold [label="mA"];
    threshold -> debounce [label="bool"];
    debounce -> events [label="tool_on/off"];
    events -> gate_logic [label="subscribe"];
    events -> fan_logic [label="subscribe"];
}}'''
        
        self._run_dot(dot, self.output_dir / 'dataflow_diagram.png')
    
    def generate_state_machine(self):
        """Generate gate control state machine"""
        print("🔄 Generating state machine diagram...")
        
        dot = f'''digraph state_machine {{
    rankdir=LR;
    bgcolor="{COLORS['background']}";
    node [shape=circle, style=filled, fontname="Arial"];
    edge [fontname="Arial"];
    
    // States
    start [shape=doublecircle, fillcolor="{COLORS['border']}"];
    closed [label="CLOSED", fillcolor="{COLORS['gate']}"];
    opening [label="OPENING", fillcolor="{COLORS['util']}"];
    open [label="OPEN", fillcolor="{COLORS['tasks']}"];
    closing [label="CLOSING", fillcolor="{COLORS['util']}"];
    
    // Transitions
    start -> closed;
    closed -> opening [label="tool_on"];
    opening -> open [label="servo_done"];
    open -> closing [label="tool_off"];
    closing -> closed [label="servo_done"];
    
    // Self loops
    closed -> closed [label="tool_off"];
    open -> open [label="tool_on"];
}}'''
        
        self._run_dot(dot, self.output_dir / 'state_machine.png')
    
    def generate_event_flow(self):
        """Generate event publish/subscribe diagram"""
        print("📡 Generating event flow diagram...")
        
        if not self.analyzer.event_publishers:
            print("   ⚠ No events found in code - generating example diagram")
            events = {
                'tool_on': (['tool_monitor'], ['gate_control', 'fan_control']),
                'tool_off': (['tool_monitor'], ['gate_control', 'fan_control']),
                'gate_opened': (['gate_control'], ['fan_control']),
                'gate_closed': (['gate_control'], ['fan_control']),
                'fan_on': (['fan_control'], []),
                'air_quality': (['air_monitor'], [])
            }
        else:
            events = {
                event: (list(self.analyzer.event_publishers[event]),
                       list(self.analyzer.event_subscribers[event]))
                for event in self.analyzer.event_publishers.keys()
            }
        
        dot_lines = [
            'digraph event_flow {',
            '    rankdir=LR;',
            f'    bgcolor="{COLORS["background"]}";',
            '    node [shape=box, style="rounded,filled", fontname="Arial"];',
            '    edge [fontname="Arial"];',
            ''
        ]
        
        # Create nodes for publishers and subscribers
        publishers = set()
        subscribers = set()
        for pubs, subs in events.values():
            publishers.update(pubs)
            subscribers.update(subs)
        
        # Publisher nodes
        dot_lines.append('    subgraph cluster_publishers {')
        dot_lines.append('        label="Publishers";')
        dot_lines.append(f'        fillcolor="{COLORS["event_bus"]}20";')
        dot_lines.append('        style=filled;')
        for pub in sorted(publishers):
            name = pub.split('.')[-1]
            dot_lines.append(f'        pub_{name} [label="{name}", fillcolor="{COLORS["event_bus"]}"];')
        dot_lines.append('    }')
        dot_lines.append('')
        
        # Event nodes
        dot_lines.append('    subgraph cluster_events {')
        dot_lines.append('        label="Events";')
        dot_lines.append(f'        fillcolor="{COLORS["util"]}20";')
        dot_lines.append('        style=filled;')
        for event in sorted(events.keys()):
            dot_lines.append(f'        evt_{event} [label="{event}", shape=ellipse, fillcolor="{COLORS["util"]}"];')
        dot_lines.append('    }')
        dot_lines.append('')
        
        # Subscriber nodes
        if subscribers:
            dot_lines.append('    subgraph cluster_subscribers {')
            dot_lines.append('        label="Subscribers";')
            dot_lines.append(f'        fillcolor="{COLORS["tasks"]}20";')
            dot_lines.append('        style=filled;')
            for sub in sorted(subscribers):
                name = sub.split('.')[-1]
                dot_lines.append(f'        sub_{name} [label="{name}", fillcolor="{COLORS["tasks"]}"];')
            dot_lines.append('    }')
            dot_lines.append('')
        
        # Connections
        for event, (pubs, subs) in events.items():
            for pub in pubs:
                pub_name = pub.split('.')[-1]
                dot_lines.append(f'    pub_{pub_name} -> evt_{event} [label="publish"];')
            for sub in subs:
                sub_name = sub.split('.')[-1]
                dot_lines.append(f'    evt_{event} -> sub_{sub_name} [label="subscribe"];')
        
        dot_lines.append('}')
        
        self._run_dot('\n'.join(dot_lines), self.output_dir / 'event_flow.png')
    
    def generate_components(self):
        """Generate component architecture diagram"""
        print("🏗️  Generating component architecture...")
        
        # Group modules by layer
        layers = {
            'hardware': [],
            'tasks': [],
            'util': [],
            'other': []
        }
        
        for module in self.analyzer.modules.keys():
            if 'hardware' in module:
                layers['hardware'].append(module)
            elif 'tasks' in module:
                layers['tasks'].append(module)
            elif 'util' in module:
                layers['util'].append(module)
            else:
                layers['other'].append(module)
        
        dot_lines = [
            'digraph components {',
            '    rankdir=TB;',
            f'    bgcolor="{COLORS["background"]}";',
            '    node [shape=box, style="rounded,filled", fontname="Arial"];',
            '    edge [fontname="Arial"];',
            ''
        ]
        
        # Create layers
        for layer_name, color in [('hardware', 'hardware'), ('tasks', 'tasks'), ('util', 'util')]:
            if layers[layer_name]:
                dot_lines.append(f'    subgraph cluster_{layer_name} {{')
                dot_lines.append(f'        label="{layer_name.title()} Layer";')
                dot_lines.append(f'        fillcolor="{COLORS[color]}20";')
                dot_lines.append('        style=filled;')
                for module in sorted(layers[layer_name]):
                    name = module.split('.')[-1]
                    dot_lines.append(f'        {name} [fillcolor="{COLORS[color]}"];')
                dot_lines.append('    }')
                dot_lines.append('')
        
        dot_lines.append('}')
        
        self._run_dot('\n'.join(dot_lines), self.output_dir / 'component_architecture.png')
    
    def generate_modules(self):
        """Generate module dependency graph"""
        print("📦 Generating module dependencies...")
        
        dot_lines = [
            'digraph modules {',
            '    rankdir=LR;',
            f'    bgcolor="{COLORS["background"]}";',
            '    node [shape=box, style="rounded,filled", fontname="Arial"];',
            '    edge [fontname="Arial"];',
            ''
        ]
        
        # Add all modules as nodes
        for module in sorted(self.analyzer.modules.keys()):
            name = module.split('.')[-1]
            color = COLORS['hardware'] if 'hardware' in module else \
                    COLORS['tasks'] if 'tasks' in module else \
                    COLORS['util'] if 'util' in module else \
                    COLORS['border']
            dot_lines.append(f'    {name} [fillcolor="{color}"];')
        
        dot_lines.append('')
        
        # Add import relationships
        for module, imports in self.analyzer.imports.items():
            source_name = module.split('.')[-1]
            for imp in imports:
                # Only show local imports
                if imp.startswith('src.') or imp.startswith('.'):
                    target_name = imp.split('.')[-1]
                    if target_name in [m.split('.')[-1] for m in self.analyzer.modules.keys()]:
                        dot_lines.append(f'    {source_name} -> {target_name};')
        
        dot_lines.append('}')
        
        self._run_dot('\n'.join(dot_lines), self.output_dir / 'module_dependencies.png')


def main():
    """Main entry point"""
    # Determine what to generate
    if len(sys.argv) > 1:
        diagram_type = sys.argv[1].lower()
    else:
        diagram_type = 'all'
    
    # Find source directory
    script_dir = Path(__file__).parent
    project_root = script_dir.parent if script_dir.name == 'analysis' else script_dir
    src_dir = project_root / 'src'
    
    if not src_dir.exists():
        print(f"❌ Error: Source directory not found: {src_dir}")
        print(f"   Script location: {Path(__file__)}")
        print(f"   Detected project root: {project_root}")
        print()
        print("Expected project structure:")
        print("   DustCollectorSoftware/")
        print("   ├── analysis/          (you are here)")
        print("   │   └── generate_diagrams.py")
        print("   └── src/               (not found!)")
        print("       ├── hardware/")
        print("       ├── tasks/")
        print("       └── util/")
        print()
        print("Actual structure found:")
        if project_root.exists():
            print(f"   {project_root}/")
            for item in sorted(project_root.iterdir()):
                if item.is_dir() and not item.name.startswith('.'):
                    print(f"   ├── {item.name}/")
        sys.exit(1)
    
    # Output directory
    output_dir = script_dir / 'diagrams' if script_dir.name == 'analysis' else script_dir / 'dust_collector_diagrams'
    
    print(f"🎯 Dust Collector System Analysis")
    print(f"   Script: {Path(__file__)}")
    print(f"   Script dir: {script_dir}")
    print(f"   Project root: {project_root}")
    print(f"   Source: {src_dir}")
    print(f"   Output: {output_dir}")
    print()
    
    # Analyze code
    analyzer = CodeAnalyzer(src_dir)
    analyzer.analyze()
    print()
    
    # Generate diagrams
    generator = DiagramGenerator(analyzer, output_dir)
    
    generators = {
        'architecture': generator.generate_architecture,
        'dataflow': generator.generate_dataflow,
        'statemachine': generator.generate_state_machine,
        'events': generator.generate_event_flow,
        'components': generator.generate_components,
        'modules': generator.generate_modules
    }
    
    if diagram_type == 'all':
        for gen_func in generators.values():
            gen_func()
    elif diagram_type in generators:
        generators[diagram_type]()
    else:
        print(f"❌ Unknown diagram type: {diagram_type}")
        print(f"   Valid types: all, {', '.join(generators.keys())}")
        sys.exit(1)
    
    print()
    print(f"✅ Done! Diagrams saved to: {output_dir}")
    print(f"   View them by running: ./VIEW_DIAGRAMS.sh")


if __name__ == '__main__':
    main()
